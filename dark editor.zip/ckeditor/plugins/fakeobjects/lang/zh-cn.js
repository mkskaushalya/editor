﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'zh-cn', {
	anchor: '锚点',
	hiddenfield: '隐藏域',
	iframe: 'IFrame',
	unknown: '未知对象'
} );
