﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'gu', {
	label: 'શૈલી/રીત',
	panelTitle: 'ફોર્મેટ ',
	panelTitle1: 'બ્લોક ',
	panelTitle2: 'ઈનલાઈન ',
	panelTitle3: 'ઓબ્જેક્ટ પદ્ધતિ'
} );
