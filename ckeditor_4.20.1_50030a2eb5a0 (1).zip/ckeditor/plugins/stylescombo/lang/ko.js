﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ko', {
	label: '스타일',
	panelTitle: '전체 구성 스타일',
	panelTitle1: '블록 스타일',
	panelTitle2: '인라인 스타일',
	panelTitle3: '객체 스타일'
} );
