﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'uk', {
	label: 'Стиль',
	panelTitle: 'Стилі форматування',
	panelTitle1: 'Блочні стилі',
	panelTitle2: 'Рядкові стилі',
	panelTitle3: 'Об\'єктні стилі'
} );
