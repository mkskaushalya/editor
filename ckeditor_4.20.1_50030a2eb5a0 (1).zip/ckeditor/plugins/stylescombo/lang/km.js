﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'km', {
	label: 'រចនាបថ',
	panelTitle: 'ទ្រង់ទ្រាយ​រចនាបថ',
	panelTitle1: 'រចនាបថ​ប្លក់',
	panelTitle2: 'រចនាបថ​ក្នុង​ជួរ',
	panelTitle3: 'រចនាបថ​វត្ថុ'
} );
