﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'fr', {
	label: 'Styles',
	panelTitle: 'Styles de mise en forme',
	panelTitle1: 'Styles de bloc',
	panelTitle2: 'Styles en ligne',
	panelTitle3: 'Styles d\'objet'
} );
